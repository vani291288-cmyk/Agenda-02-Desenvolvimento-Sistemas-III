# Agenda 04 – Busca Dinâmica em .NET MAUI

Atividade de Desenvolvimento de Sistemas III – Agenda 04.

## Funcionalidade

Este projeto demonstra uma busca dinâmica de produtos utilizando:

- SearchBar;
- evento TextChanged;
- evento SearchButtonPressed;
- ObservableCollection;
- ListView;
- método OnAppearing.

## Como funciona

Os produtos são armazenados em uma ObservableCollection. Conforme o usuário digita no SearchBar, o evento TextChanged é acionado e o código procura o texto digitado dentro do nome dos produtos.

A coleção ProdutosFiltrados é atualizada e a ListView apresenta os resultados.

Quando o campo de pesquisa fica vazio, todos os produtos são exibidos novamente.

## Observação

Os arquivos MainPage.xaml e MainPage.xaml.cs foram preparados para serem utilizados em um projeto .NET MAUI com o namespace MauiAppMinhasCompras.
