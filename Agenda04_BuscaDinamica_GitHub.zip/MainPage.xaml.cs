using System.Collections.ObjectModel;
using MauiAppMinhasCompras.Models;

namespace MauiAppMinhasCompras;

public partial class MainPage : ContentPage
{
    private readonly ObservableCollection<Produto> _todosProdutos = new();

    public ObservableCollection<Produto> ProdutosFiltrados { get; } = new();

    public MainPage()
    {
        InitializeComponent();
        BindingContext = this;
        CarregarProdutos();
    }

    private void CarregarProdutos()
    {
        _todosProdutos.Clear();

        _todosProdutos.Add(new Produto(1, "Arroz 5kg", 28.90));
        _todosProdutos.Add(new Produto(2, "Feijão 1kg", 8.50));
        _todosProdutos.Add(new Produto(3, "Café 500g", 16.90));
        _todosProdutos.Add(new Produto(4, "Leite 1L", 5.49));
        _todosProdutos.Add(new Produto(5, "Açúcar 1kg", 4.99));
        _todosProdutos.Add(new Produto(6, "Macarrão 500g", 6.75));

        AtualizarLista(_todosProdutos);
    }

    private void AtualizarLista(IEnumerable<Produto> produtos)
    {
        ProdutosFiltrados.Clear();

        foreach (var produto in produtos)
            ProdutosFiltrados.Add(produto);
    }

    private void OnSearchTextChanged(object sender, TextChangedEventArgs e)
    {
        string texto = e.NewTextValue?.Trim() ?? string.Empty;

        if (string.IsNullOrWhiteSpace(texto))
        {
            AtualizarLista(_todosProdutos);
            return;
        }

        var resultados = _todosProdutos.Where(p =>
            p.Nome.Contains(texto, StringComparison.OrdinalIgnoreCase));

        AtualizarLista(resultados);
    }

    private void OnSearchButtonPressed(object sender, EventArgs e)
    {
        string texto = searchBar.Text?.Trim() ?? string.Empty;

        if (string.IsNullOrWhiteSpace(texto))
        {
            AtualizarLista(_todosProdutos);
            return;
        }

        var resultados = _todosProdutos.Where(p =>
            p.Nome.Contains(texto, StringComparison.OrdinalIgnoreCase));

        AtualizarLista(resultados);
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();

        if (_todosProdutos.Count == 0)
            CarregarProdutos();
    }
}
