namespace MauiAppMinhasCompras.Models;

public class Produto
{
    public int Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public double Preco { get; set; }

    public Produto()
    {
    }

    public Produto(int id, string nome, double preco)
    {
        Id = id;
        Nome = nome;
        Preco = preco;
    }
}
